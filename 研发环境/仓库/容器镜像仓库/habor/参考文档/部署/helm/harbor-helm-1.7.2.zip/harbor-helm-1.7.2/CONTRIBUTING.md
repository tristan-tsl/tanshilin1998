# Contributing to Helm Chart for Harbor

Please follow [Harbor contributing guide](https://github.com/goharbor/harbor/blob/master/CONTRIBUTING.md) to learn how to make code contribution.

## Contributers

Thanks very much to all contributers who submitted pull requests to Helm Chart for Harbor.

- [Paul Czarkowski @paulczar](https://github.com/paulczar)
- [Luca Innocenti Mirri @lucaim](https://github.com/lucaim)
- [Steven Arnott @ArcticSnowman](https://github.com/ArcticSnowman)
- [Alex M @draeron](https://github.com/draeron)
- [SangJun Yun](https://github.com/YunSangJun)
